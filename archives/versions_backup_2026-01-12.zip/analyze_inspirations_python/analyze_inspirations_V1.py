#!/usr/bin/env python3
"""
Analyse les images d'inspiration et génère des prompts optimisés.

Usage:
    python3 analyze_inspirations.py [preset_name]
    
Si aucun preset n'est spécifié, analyse tous les presets.
"""

import os
import sys
from pathlib import Path
from PIL import Image
import json
from datetime import datetime

class InspirationAnalyzer:
    """Analyse les images d'inspiration pour affiner les prompts."""
    
    def __init__(self):
        self.base_dir = Path(__file__).parent / "inspirations"
        self.output_dir = Path(__file__).parent / "prompts"
        self.output_dir.mkdir(exist_ok=True)
        
        self.presets = [
            "dune_epic",
            "arrival_minimal", 
            "spaceship_arrival",
            "human_contemplative",
            "brutalist_architecture",
            "portal_tunnel",
            "underwater_alien",
            "custom"
        ]
    
    def analyze_image_properties(self, image_path: Path) -> dict:
        """Analyse les propriétés techniques d'une image."""
        try:
            img = Image.open(image_path)
            
            # Propriétés basiques
            width, height = img.size
            aspect_ratio = width / height
            mode = img.mode
            
            # Dominance de couleurs (simplifiée)
            colors = img.getcolors(maxcolors=1000000)
            if colors:
                # Trier par fréquence
                sorted_colors = sorted(colors, key=lambda x: x[0], reverse=True)
                dominant_colors = sorted_colors[:5]
            else:
                dominant_colors = []
            
            # Luminosité moyenne
            grayscale = img.convert('L')
            pixels = list(grayscale.getdata())
            avg_brightness = sum(pixels) / len(pixels) / 255.0
            
            return {
                "filename": image_path.name,
                "dimensions": f"{width}x{height}",
                "aspect_ratio": round(aspect_ratio, 2),
                "mode": mode,
                "brightness": round(avg_brightness, 2),
                "is_dark": avg_brightness < 0.4,
                "is_bright": avg_brightness > 0.7,
                "dominant_colors_count": len(dominant_colors)
            }
        except Exception as e:
            print(f"⚠️  Erreur analyse {image_path.name}: {e}")
            return {}
    
    def generate_style_keywords(self, images_data: list) -> list:
        """Génère des mots-clés de style basés sur les propriétés des images."""
        keywords = []
        
        # Analyse luminosité
        dark_count = sum(1 for img in images_data if img.get("is_dark", False))
        bright_count = sum(1 for img in images_data if img.get("is_bright", False))
        
        if dark_count > len(images_data) / 2:
            keywords.extend(["low-key lighting", "moody atmosphere", "dramatic shadows"])
        elif bright_count > len(images_data) / 2:
            keywords.extend(["high-key lighting", "bright atmosphere", "soft shadows"])
        
        # Analyse aspect ratio
        wide_count = sum(1 for img in images_data if img.get("aspect_ratio", 1) > 2)
        if wide_count > len(images_data) / 2:
            keywords.append("cinematic wide composition")
        
        return keywords
    
    def analyze_preset(self, preset_name: str) -> dict:
        """Analyse toutes les images d'un preset."""
        preset_dir = self.base_dir / preset_name
        
        if not preset_dir.exists():
            return None
        
        # Trouver toutes les images
        image_extensions = ['.jpg', '.jpeg', '.png', '.webp', '.bmp']
        images = []
        for ext in image_extensions:
            images.extend(preset_dir.glob(f"*{ext}"))
            images.extend(preset_dir.glob(f"*{ext.upper()}"))
        
        if not images:
            return None
        
        print(f"\n📁 Analyse de '{preset_name}' ({len(images)} images)...")
        
        # Analyser chaque image
        images_data = []
        for img_path in images:
            data = self.analyze_image_properties(img_path)
            if data:
                images_data.append(data)
                print(f"   ✓ {img_path.name}")
        
        # Générer les mots-clés de style
        style_keywords = self.generate_style_keywords(images_data)
        
        result = {
            "preset": preset_name,
            "analyzed_at": datetime.now().isoformat(),
            "image_count": len(images_data),
            "images": images_data,
            "style_keywords": style_keywords,
            "suggestions": self.generate_suggestions(preset_name, images_data, style_keywords)
        }
        
        return result
    
    def generate_suggestions(self, preset_name: str, images_data: list, style_keywords: list) -> dict:
        """Génère des suggestions pour améliorer le prompt."""
        
        avg_brightness = sum(img.get("brightness", 0.5) for img in images_data) / len(images_data)
        
        suggestions = {
            "lighting": [],
            "atmosphere": [],
            "composition": [],
            "color_grading": []
        }
        
        # Suggestions lighting
        if avg_brightness < 0.3:
            suggestions["lighting"].extend([
                "deep shadows",
                "dramatic contrast",
                "chiaroscuro lighting"
            ])
        elif avg_brightness < 0.5:
            suggestions["lighting"].extend([
                "moody lighting",
                "soft shadows",
                "atmospheric haze"
            ])
        elif avg_brightness > 0.7:
            suggestions["lighting"].extend([
                "bright diffused light",
                "soft ambient lighting",
                "ethereal glow"
            ])
        
        # Suggestions atmosphère basées sur le preset
        if "dune" in preset_name or "desert" in preset_name:
            suggestions["atmosphere"].extend([
                "heat haze",
                "dust particles in air",
                "golden hour warmth"
            ])
        elif "underwater" in preset_name:
            suggestions["atmosphere"].extend([
                "volumetric light rays",
                "particle suspension",
                "depth atmosphere"
            ])
        elif "space" in preset_name:
            suggestions["atmosphere"].extend([
                "void darkness",
                "stellar background",
                "cosmic scale"
            ])
        
        # Suggestions composition
        wide_images = sum(1 for img in images_data if img.get("aspect_ratio", 1) > 1.8)
        if wide_images > len(images_data) / 2:
            suggestions["composition"].extend([
                "ultra-wide angle",
                "panoramic vista",
                "epic scale"
            ])
        
        return suggestions
    
    def save_analysis(self, preset_name: str, analysis: dict):
        """Sauvegarde l'analyse en JSON."""
        output_file = self.output_dir / f"{preset_name}_analysis.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(analysis, f, indent=2, ensure_ascii=False)
        
        print(f"\n💾 Analyse sauvegardée: {output_file}")
    
    def generate_enhanced_prompt(self, preset_name: str, analysis: dict) -> str:
        """Génère un prompt amélioré basé sur l'analyse."""
        
        # Charger le prompt de base
        from src.prompt_templates import PRESET_PROMPTS
        base_prompt = PRESET_PROMPTS.get(preset_name, {}).get("base_prompt", "")
        
        if not base_prompt:
            return ""
        
        # Ajouter les style keywords
        style_section = ", ".join(analysis["style_keywords"]) if analysis["style_keywords"] else ""
        
        # Ajouter les suggestions les plus pertinentes
        suggestions = analysis.get("suggestions", {})
        lighting_hints = ", ".join(suggestions.get("lighting", [])[:2])
        atmosphere_hints = ", ".join(suggestions.get("atmosphere", [])[:2])
        
        # Construire le prompt enrichi
        enhancements = []
        if style_section:
            enhancements.append(style_section)
        if lighting_hints:
            enhancements.append(lighting_hints)
        if atmosphere_hints:
            enhancements.append(atmosphere_hints)
        
        if enhancements:
            enhanced = f"{base_prompt}, {', '.join(enhancements)}"
        else:
            enhanced = base_prompt
        
        return enhanced
    
    def display_analysis(self, analysis: dict):
        """Affiche l'analyse de façon lisible."""
        print("\n" + "="*70)
        print(f"📊 ANALYSE: {analysis['preset'].upper()}")
        print("="*70)
        
        print(f"\n📷 Images analysées: {analysis['image_count']}")
        
        if analysis['style_keywords']:
            print(f"\n🎨 Style détecté:")
            for keyword in analysis['style_keywords']:
                print(f"   • {keyword}")
        
        suggestions = analysis.get('suggestions', {})
        if any(suggestions.values()):
            print(f"\n💡 Suggestions pour améliorer le prompt:")
            
            for category, items in suggestions.items():
                if items:
                    print(f"\n   {category.upper()}:")
                    for item in items[:3]:  # Top 3
                        print(f"   • {item}")
        
        # Afficher le prompt enrichi
        enhanced = self.generate_enhanced_prompt(analysis['preset'], analysis)
        if enhanced:
            print(f"\n✨ PROMPT ENRICHI:")
            print(f"   {enhanced[:200]}...")
    
    def run(self, preset_name: str = None):
        """Lance l'analyse."""
        
        print("\n" + "="*70)
        print("🎨 ANALYSEUR D'INSPIRATIONS VISUELLES")
        print("="*70)
        
        if preset_name:
            # Analyser un seul preset
            if preset_name not in self.presets:
                print(f"❌ Preset inconnu: {preset_name}")
                print(f"   Presets disponibles: {', '.join(self.presets)}")
                return
            
            analysis = self.analyze_preset(preset_name)
            if analysis:
                self.display_analysis(analysis)
                self.save_analysis(preset_name, analysis)
            else:
                print(f"⚠️  Aucune image trouvée dans inspirations/{preset_name}/")
                print(f"   Ajoutez des images d'inspiration dans ce dossier.")
        
        else:
            # Analyser tous les presets qui ont des images
            analyzed_count = 0
            
            for preset in self.presets:
                analysis = self.analyze_preset(preset)
                if analysis:
                    self.display_analysis(analysis)
                    self.save_analysis(preset, analysis)
                    analyzed_count += 1
            
            if analyzed_count == 0:
                print("\n⚠️  Aucune image d'inspiration trouvée.")
                print("\n💡 Pour commencer:")
                print("   1. Placez vos images dans: inspirations/[preset_name]/")
                print("   2. Relancez: python3 analyze_inspirations.py")
            else:
                print(f"\n✅ {analyzed_count} preset(s) analysé(s)")
        
        print("\n" + "="*70)


def main():
    """Point d'entrée principal."""
    
    analyzer = InspirationAnalyzer()
    
    # Vérifier les arguments
    if len(sys.argv) > 1:
        preset_name = sys.argv[1]
        analyzer.run(preset_name)
    else:
        analyzer.run()


if __name__ == "__main__":
    main()
