#!/usr/bin/env python3
"""
🎬 GÉNÉRATEUR DE VIDÉOS CINÉMATIQUES
Style : Hyperréalisme - Dune/Arrival

Point d'entrée principal avec interface interactive.
"""
import subprocess
import os
import sys
import subprocess
from pathlib import Path

# Ajouter le projet au path
sys.path.insert(0, str(Path(__file__).parent))

from src.video_generator import VideoGenerator
from src.batch_processor import BatchProcessor, EXAMPLE_STORYBOARDS
from prompts.prompt_templates import STYLE_PRESETS


def print_banner():
    """Affiche le banner de l'application."""
    print("\n" + "="*70)
    print("🎬  GÉNÉRATEUR DE VIDÉOS CINÉMATIQUES AI")
    print("="*70)
    print("\n   Style : Hyperréalisme - Dune/Arrival/Denis Villeneuve")
    print("   Engine : Kling AI via PiAPI")
    print("   Mode : standard | Pay-as-you-go\n")
    print("="*70 + "\n")


def print_menu():
    """Affiche le menu principal."""
    print("\n📋 MENU PRINCIPAL :\n")
    print("  1. 🎨 Générer avec un preset (recommandé)")
    print("  2. ✍️  Générer avec un prompt personnalisé")
    print("  3. 🎞️  Générer une séquence/storyboard")
    print("  4. 📦 Générer un batch depuis un fichier")
    print("  5. 🌟 Enrichir les presets avec des inspirations")
    print("  6. 📜 Restaurer une version précédente d'un preset")
    print("  7. 📚 Voir les presets disponibles")
    print("  8. 💳 Vérifier mes crédits")
    print("  9. 🔑 Configuration API")
    print(" 10. ➕ Créer un nouveau preset")
    print(" 11. ✏️  Modifier un preset")
    print("  0. 🚪 Quitter")
    print()


def mode_preset(generator: VideoGenerator):
    """Mode génération avec preset."""
    print("\n" + "="*70)
    print("🎨 GÉNÉRATION AVEC PRESET")
    print("="*70 + "\n")
    
    # Afficher les presets
    presets = list(STYLE_PRESETS.keys())
    for i, name in enumerate(presets, 1):
        preset = STYLE_PRESETS[name]
        print(f"  {i}. {name}")
        print(f"     {preset['base'][:60]}...")
        print()
    
    # Choix
    try:
        choice = int(input("Choisissez un preset (numéro) : ")) - 1
        if choice < 0 or choice >= len(presets):
            print("❌ Choix invalide")
            return
        
        preset_name = presets[choice]
        
        # Durée
        duration = input("\nDurée (5 ou 10 secondes) [5] : ").strip()
        duration = int(duration) if duration else 5
        
        if duration not in [5, 10]:
            print("❌ Durée invalide, utilisation de 5s")
            duration = 5
        
        # Ratio
        print("\nRatio d'aspect :")
        print("  1. 16:9 (paysage, recommandé)")
        print("  2. 9:16 (portrait)")
        print("  3. 1:1 (carré)")
        
        ratio_choice = input("Choix [1] : ").strip()
        ratios = ["16:9", "9:16", "1:1"]
        aspect_ratio = ratios[int(ratio_choice) - 1] if ratio_choice else "16:9"
        
        # Nom de fichier
        filename = input("\nNom du fichier (optionnel) : ").strip()
        
        print("\n🚀 Génération en cours...\n")
        
        # Générer
        video_path = generator.generate(
            preset=preset_name,
            duration=duration,
            aspect_ratio=aspect_ratio,
            custom_filename=filename if filename else None
        )
        
        print(f"\n✅ Vidéo disponible : {video_path}")
        
    except ValueError:
        print("❌ Entrée invalide")
    except KeyboardInterrupt:
        print("\n\n⚠️  Génération annulée")
    except Exception as e:
        print(f"\n❌ Erreur : {e}")


def mode_custom_prompt(generator: VideoGenerator):
    """Mode génération avec prompt personnalisé."""
    print("\n" + "="*70)
    print("✍️  GÉNÉRATION AVEC PROMPT PERSONNALISÉ")
    print("="*70 + "\n")
    
    print("💡 Conseils :")
    print("  - Soyez précis et détaillé")
    print("  - Incluez : sujet, style, éclairage, mouvement caméra")
    print("  - Mentionnez 'cinematic', 'photorealistic' pour meilleure qualité\n")
    
    # Prompt
    prompt = input("Votre prompt : ").strip()
    
    if not prompt:
        print("❌ Prompt vide")
        return
    
    # Utiliser un preset pour le style ?
    use_preset = input("\nUtiliser un preset pour le style ? (o/N) : ").strip().lower()
    
    preset = None
    if use_preset == 'o':
        print("\nPresets disponibles :")
        presets = list(STYLE_PRESETS.keys())
        for i, name in enumerate(presets, 1):
            print(f"  {i}. {name}")
        
        try:
            choice = int(input("\nChoix : ")) - 1
            preset = presets[choice]
        except:
            print("⚠️  Pas de preset, génération avec prompt seul")
    
    # Durée
    duration = input("\nDurée (5 ou 10 secondes) [5] : ").strip()
    duration = int(duration) if duration else 5
    
    print("\n🚀 Génération en cours...\n")
    
    try:
        video_path = generator.generate(
            prompt=prompt,
            preset=preset,
            duration=duration
        )
        
        print(f"\n✅ Vidéo disponible : {video_path}")
    
    except Exception as e:
        print(f"\n❌ Erreur : {e}")


def mode_sequence(generator: VideoGenerator):
    """Mode génération de séquence."""
    print("\n" + "="*70)
    print("🎞️  GÉNÉRATION DE SÉQUENCE")
    print("="*70 + "\n")
    
    print("Storyboards prédéfinis :\n")
    
    storyboards = list(EXAMPLE_STORYBOARDS.keys())
    for i, name in enumerate(storyboards, 1):
        scenes = EXAMPLE_STORYBOARDS[name]
        print(f"  {i}. {name} ({len(scenes)} scènes)")
    
    print(f"  {len(storyboards) + 1}. Créer une séquence personnalisée")
    
    try:
        choice = int(input("\nChoix : ")) - 1
        
        if choice < 0 or choice > len(storyboards):
            print("❌ Choix invalide")
            return
        
        if choice < len(storyboards):
            # Storyboard prédéfini
            storyboard_name = storyboards[choice]
            scenes = EXAMPLE_STORYBOARDS[storyboard_name]
            
            project_name = input(f"\nNom du projet [{storyboard_name}] : ").strip()
            project_name = project_name if project_name else storyboard_name
            
            print(f"\n🚀 Génération de {len(scenes)} scènes...\n")
            
            video_paths = generator.generate_sequence(scenes, project_name)
            
            print(f"\n✅ Séquence terminée : {len(video_paths)} vidéos")
        
        else:
            # Séquence personnalisée
            print("\n📝 Création de séquence personnalisée")
            print("Entrez vos scènes (prompt ou preset), une ligne vide pour terminer\n")
            
            scenes = []
            scene_num = 1
            
            while True:
                print(f"Scène {scene_num} :")
                preset_or_prompt = input("  Preset ou prompt (vide pour finir) : ").strip()
                
                if not preset_or_prompt:
                    break
                
                # C'est un preset ?
                if preset_or_prompt in STYLE_PRESETS:
                    scenes.append({"preset": preset_or_prompt})
                else:
                    scenes.append({"prompt": preset_or_prompt})
                
                scene_num += 1
            
            if scenes:
                project_name = input("\nNom du projet : ").strip()
                
                print(f"\n🚀 Génération de {len(scenes)} scènes...\n")
                
                video_paths = generator.generate_sequence(scenes, project_name)
                
                print(f"\n✅ Séquence terminée : {len(video_paths)} vidéos")
            else:
                print("⚠️  Aucune scène créée")
    
    except ValueError:
        print("❌ Entrée invalide")
    except Exception as e:
        print(f"\n❌ Erreur : {e}")


def mode_batch(processor: BatchProcessor):
    """Mode génération batch depuis fichier."""
    print("\n" + "="*70)
    print("📦 GÉNÉRATION BATCH DEPUIS FICHIER")
    print("="*70 + "\n")
    
    print("Formats supportés :")
    print("  • .txt : Un prompt par ligne")
    print("  • .json : Liste de configs de scènes\n")
    
    filepath = input("Chemin du fichier : ").strip()
    
    if not filepath:
        print("❌ Chemin vide")
        return
    
    filepath = Path(filepath)
    
    if not filepath.exists():
        print(f"❌ Fichier introuvable : {filepath}")
        return
    
    batch_name = input(f"Nom du batch [{filepath.stem}] : ").strip()
    batch_name = batch_name if batch_name else filepath.stem
    
    print(f"\n🚀 Traitement du batch...\n")
    
    try:
        results = processor.process_from_file(str(filepath), batch_name)
        
        print(f"\n✅ Batch terminé !")
        print(f"   Réussies : {len(results['successful'])}")
        print(f"   Échouées : {len(results['failed'])}")
    
    except Exception as e:
        print(f"\n❌ Erreur : {e}")


def show_presets():
    """Affiche les presets disponibles."""
    print("\n" + "="*70)
    print("📚 PRESETS DISPONIBLES")
    print("="*70 + "\n")
    
    for name, preset in STYLE_PRESETS.items():
        print(f"🎨 {name.upper()}")
        print(f"   Base : {preset['base']}")
        print(f"   Style : {preset['color']}")
        print(f"   Caméra : {preset['camera']}")
        print(f"   Qualité : {preset['quality']}")
        print()
    
    input("\nAppuyez sur Entrée pour continuer...")


def check_credits(generator: VideoGenerator):
    """Vérifie les crédits."""
    print("\n" + "="*70)
    print("💳 VÉRIFICATION DES CRÉDITS")
    print("="*70 + "\n")
    
    try:
        generator.check_credits()
    except Exception as e:
        print(f"❌ Erreur : {e}")
    
    input("\nAppuyez sur Entrée pour continuer...")




def enrich_presets_menu():
    """Menu pour enrichir les presets avec les analyses."""
    
    print("\n" + "="*70)
    print("🌟 ENRICHISSEMENT DES PRESETS")
    print("="*70)
    
    print("\n📋 Ce menu vous permet d'enrichir vos presets avec les analyses")
    print("   d'images que vous avez effectuées.")
    print("\n💡 Workflow:")
    print("   1. Ajoutez des images dans inspirations/[preset_name]/")
    print("   2. Lancez: python3 analyze_inspirations.py [preset_name]")
    print("   3. Utilisez ce menu pour appliquer les suggestions")
    
    print("\n" + "="*70)
    
    # Vérifier si des analyses existent
    prompts_dir = Path("prompts")
    analyses = list(prompts_dir.glob("*_analysis.json"))
    
    if not analyses:
        print("\n⚠️  Aucune analyse trouvée")
        print("\n💡 Pour créer une analyse:")
        print("   1. Placez des images dans: inspirations/dune_epic/")
        print("   2. Lancez: python3 analyze_inspirations.py dune_epic")
        input("\n⏎  Appuyez sur Entrée pour continuer...")
        return
    
    # Lancer le script d'application
    print("\n🚀 Lancement de l'assistant d'enrichissement...\n")
    
    try:
        subprocess.run(["python3", "apply_suggestions.py"], check=True)
    except subprocess.CalledProcessError:
        print("\n❌ Erreur lors de l'enrichissement")
    except FileNotFoundError:
        print("\n❌ Fichier apply_suggestions.py introuvable")
    
    input("\n⏎  Appuyez sur Entrée pour revenir au menu...")


def restore_preset_menu():
    """Menu pour restaurer une version précédente d'un preset."""
    
    print("\n" + "="*70)
    print("📜 RESTAURATION DE PRESETS")
    print("="*70)
    
    print("\n📋 Ce menu vous permet de restaurer une version précédente")
    print("   d'un preset si vous n'êtes pas satisfait des modifications.")
    
    print("\n💡 Fonctionnement:")
    print("   • Chaque modification crée automatiquement un backup")
    print("   • Vous pouvez voir l'historique complet")
    print("   • Vous pouvez comparer avant/après")
    print("   • Vous pouvez revenir en arrière à tout moment")
    
    print("\n" + "="*70)
    
    # Lister les presets disponibles
    try:
        # Vérifier si les modules existent
        try:
            from src.prompt_templates import list_presets
        except:
            from prompts.prompt_templates import STYLE_PRESETS
            def list_presets():
                return list(STYLE_PRESETS.keys())
        
        from prompt_manager import PromptVersionManager
        
        manager = PromptVersionManager()
        presets = list_presets()
        
        presets_with_history = []
        
        print("\n📦 Presets avec historique:\n")
        
        for i, preset in enumerate(presets, 1):
            versions = manager.get_versions(preset)
            if versions:
                presets_with_history.append(preset)
                print(f"   {i}. {preset} ({len(versions)} version(s))")
        
        if not presets_with_history:
            print("   ⚠️  Aucun historique disponible")
            print("\n💡 L'historique se crée automatiquement quand vous enrichissez un preset")
            input("\n⏎  Appuyez sur Entrée pour continuer...")
            return
        
        print("\n" + "="*70)
        
        # Demander le preset
        choice = input("\n❓ Quel preset restaurer ? (numéro ou nom, ou 'q' pour annuler): ").strip()
        
        if choice.lower() == 'q':
            return
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(presets_with_history):
                preset_name = presets_with_history[idx]
            else:
                print("❌ Numéro invalide")
                input("\n⏎  Appuyez sur Entrée pour continuer...")
                return
        elif choice in presets_with_history:
            preset_name = choice
        else:
            print("❌ Preset non reconnu")
            input("\n⏎  Appuyez sur Entrée pour continuer...")
            return
        
        # Lancer le script de restauration
        print(f"\n🚀 Lancement de la restauration pour '{preset_name}'...\n")
        
        try:
            subprocess.run(["python3", "restore_prompt.py", preset_name], check=True)
        except subprocess.CalledProcessError:
            print("\n❌ Erreur lors de la restauration")
        except FileNotFoundError:
            print("\n❌ Fichier restore_prompt.py introuvable")
        
    except Exception as e:
        print(f"\n❌ Erreur: {e}")
    
    input("\n⏎  Appuyez sur Entrée pour revenir au menu...")




def create_preset_menu():
    """Menu pour créer un nouveau preset personnalisé."""
    
    print("\n" + "="*70)
    print("➕ CRÉER UN NOUVEAU PRESET")
    print("="*70)
    
    print("\n📋 Ce menu vous permet de créer un preset réutilisable")
    print("   basé sur votre propre prompt et style.")
    
    print("\n💡 Avantages :")
    print("   • Sauvegarder vos meilleurs prompts")
    print("   • Réutiliser facilement vos styles favoris")
    print("   • Partager vos presets avec d'autres")
    print("   • Enrichir avec des analyses d'images")
    
    print("\n" + "="*70)
    
    # Lancer le script de création
    print("\n🚀 Lancement de l'assistant de création...\n")
    
    try:
        subprocess.run(["python3", "create_preset.py"], check=True)
    except subprocess.CalledProcessError:
        print("\n❌ Erreur lors de la création du preset")
    except FileNotFoundError:
        print("\n❌ Fichier create_preset.py introuvable")
        print("\n💡 Assurez-vous que create_preset.py est dans le même dossier")
    except KeyboardInterrupt:
        print("\n\n⚠️  Création annulée")
    
    input("\n⏎  Appuyez sur Entrée pour revenir au menu...")


def configure_api():
    """Configuration de l'API."""
    print("\n" + "="*70)
    print("🔑 CONFIGURATION API PIAPI")
    print("="*70 + "\n")
    
    print("📖 Pour obtenir votre clé API PiAPI :\n")
    print("  1. Allez sur https://piapi.ai")
    print("  2. Créez un compte (Email/Google/GitHub)")
    print("  3. Dashboard → API Keys")
    print("  4. Create New API Key")
    print("  5. Copiez la clé (format: sk_...)")
    print("  6. Rechargez votre compte (Billing → Add Credits)\n")
    
    print("💡 Avantages PiAPI :")
    print("   - $0 frais minimum")
    print("   - Pay-as-you-go : $0.33/vidéo 5s")
    print("   - Accès immédiat\n")
    
    api_key = input("Votre clé API PiAPI (ou Entrée pour annuler) : ").strip()
    
    if api_key:
        # Sauvegarder dans .env
        env_path = Path(".env")
        
        with open(env_path, 'w') as f:
            f.write(f"PIAPI_API_KEY={api_key}\n")
        
        print(f"\n✅ Clé API sauvegardée dans {env_path}")
        print("   Redémarrez le programme pour l'utiliser")
    else:
        print("\n⚠️  Configuration annulée")
    
    input("\nAppuyez sur Entrée pour continuer...")


def main():
    """Point d'entrée principal."""
    print_banner()
    
    # Charger les variables d'environnement
    from dotenv import load_dotenv
    load_dotenv()
    
    # Vérifier la clé API (chercher d'abord PIAPI_API_KEY, puis KLING_API_KEY)
    api_key = os.getenv("PIAPI_API_KEY") or os.getenv("KLING_API_KEY")
    
    if not api_key:
        print("⚠️  AUCUNE CLÉ API CONFIGURÉE\n")
        print("Pour utiliser le générateur, vous devez configurer votre clé API PiAPI.\n")
        
        configure_now = input("Configurer maintenant ? (O/n) : ").strip().lower()
        
        if configure_now != 'n':
            configure_api()
            print("\nRedémarrez le programme pour continuer.")
            return
        else:
            print("\n⚠️  Impossible de continuer sans clé API")
            return
    
    # Initialiser
    try:
        generator = VideoGenerator()
        processor = BatchProcessor()
    except Exception as e:
        print(f"\n❌ Erreur d'initialisation : {e}")
        print("\nVérifiez votre clé API avec l'option 9 du menu.")
        return
    
    # Boucle principale
    while True:
        try:
            print_menu()
            choice = input("Votre choix : ").strip()
            
            if choice == '1':
                mode_preset(generator)
            
            elif choice == '2':
                mode_custom_prompt(generator)
            
            elif choice == '3':
                mode_sequence(generator)
            
            elif choice == '4':
                mode_batch(processor)
            
            elif choice == '5':
                enrich_presets_menu()
            
            elif choice == '6':
                restore_preset_menu()
            
            elif choice == '7':
                show_presets()
            
            elif choice == '8':
                check_credits(generator)
            
            elif choice == '9':
                configure_api()
            
            elif choice == '10':
                create_preset_menu()
            
            elif choice == '11':
                edit_preset_menu()            
            
            elif choice == '0':
                print("\n👋 Au revoir !\n")
                break
            
            else:
                print("\n❌ Choix invalide")
        
        except KeyboardInterrupt:
            print("\n\n👋 Au revoir !\n")
            break
        
        except Exception as e:
            print(f"\n❌ Erreur : {e}\n")

def edit_preset_menu():
    """Sous-menu pour modifier un preset existant."""
    
    print("\n" + "="*70)
    print("✏️  MODIFICATION DE PRESET")
    print("="*70)
    print("📋 Ce menu vous permet de modifier directement les champs")
    print("   d'un preset sans passer par l'analyse d'images.")
    print()
    print("💡 Fonctionnalités :")
    print("   • Modifier le prompt principal (base)")
    print("   • Modifier la palette de couleurs")
    print("   • Modifier le mouvement de caméra")
    print("   • Modifier les paramètres de qualité")
    print()
    print("⚠️  Un backup automatique est créé avant chaque modification")
    print("="*70)
    
    input("\nAppuyez sur Entrée pour continuer...")
    
    try:
        # Lancer l'éditeur interactif
        result = subprocess.run(
            ["python3", "edit_preset.py"],
            cwd=os.getcwd()
        )
        
        if result.returncode == 0:
            print("\n✅ Modification terminée")
        else:
            print("\n⚠️  Modification annulée ou erreur")
    
    except FileNotFoundError:
        print("\n❌ Erreur : edit_preset.py introuvable")
        print("💡 Assurez-vous que le fichier existe dans le dossier")
    
    except KeyboardInterrupt:
        print("\n\n❌ Annulé par l'utilisateur")
    
    input("\nAppuyez sur Entrée pour revenir au menu...")

if __name__ == "__main__":
    main()
