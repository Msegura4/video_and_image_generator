#!/usr/bin/env python3
"""
Restaure une version précédente d'un prompt.
"""

import sys
from prompt_manager import PromptVersionManager
from datetime import datetime

class PromptRestorer:
    """Gère la restauration des prompts."""
    
    def __init__(self):
        self.manager = PromptVersionManager()
    
    def show_versions(self, preset_name: str):
        """Affiche toutes les versions disponibles."""
        
        versions = self.manager.get_versions(preset_name)
        
        if not versions:
            print(f"\n⚠️  Aucune version sauvegardée pour '{preset_name}'")
            return []
        
        print("\n" + "="*70)
        print(f"📜 HISTORIQUE - {preset_name.upper()}")
        print("="*70)
        
        print(f"\n{len(versions)} version(s) disponible(s):\n")
        
        for i, version in enumerate(reversed(versions), 1):
            timestamp = version['timestamp']
            reason = version['reason']
            
            # Formater la date
            dt = datetime.strptime(timestamp, "%Y%m%d_%H%M%S")
            date_str = dt.strftime("%d/%m/%Y %H:%M:%S")
            
            reason_labels = {
                "manual_backup": "Sauvegarde manuelle",
                "before_enrichment": "Avant enrichissement",
                "before_restore": "Avant restauration"
            }
            
            reason_label = reason_labels.get(reason, reason)
            
            print(f"   {i}. {date_str} - {reason_label}")
            print(f"      ID: {version['backup_id']}")
        
        print("\n" + "="*70)
        
        return list(reversed(versions))
    
    def compare_with_current(self, preset_name: str, backup_id: str):
        """Compare une version avec la version actuelle."""
        
        comparison = self.manager.compare_versions(preset_name, backup_id)
        
        print("\n" + "="*70)
        print("📊 COMPARAISON")
        print("="*70)
        
        print("\n📝 PROMPT ACTUEL:")
        print("-" * 70)
        current_prompt = comparison['current']['base_prompt']
        print(f"\n{self._wrap_text(current_prompt)}\n")
        
        print("="*70)
        print("🔄 PROMPT DE LA VERSION SÉLECTIONNÉE:")
        print("-" * 70)
        previous_prompt = comparison['previous']['base_prompt']
        print(f"\n{self._wrap_text(previous_prompt)}\n")
        
        print("="*70)
    
    def _wrap_text(self, text: str, width: int = 68) -> str:
        """Enveloppe le texte."""
        words = text.split()
        lines = []
        current_line = []
        current_length = 0
        
        for word in words:
            if current_length + len(word) + 1 > width:
                lines.append(' '.join(current_line))
                current_line = [word]
                current_length = len(word)
            else:
                current_line.append(word)
                current_length += len(word) + 1
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return '\n'.join(lines)
    
    def restore_interactive(self, preset_name: str):
        """Mode interactif de restauration."""
        
        # Afficher les versions
        versions = self.show_versions(preset_name)
        
        if not versions:
            return
        
        # Demander choix
        choice = input("\n❓ Quelle version restaurer ? (numéro ou 'q' pour annuler): ").strip()
        
        if choice.lower() == 'q':
            print("\n❌ Annulé")
            return
        
        if not choice.isdigit():
            print("❌ Numéro invalide")
            return
        
        idx = int(choice) - 1
        
        if idx < 0 or idx >= len(versions):
            print("❌ Numéro invalide")
            return
        
        version = versions[idx]
        backup_id = version['backup_id']
        
        # Comparer
        self.compare_with_current(preset_name, backup_id)
        
        # Confirmer
        response = input("\n❓ Restaurer cette version ? (oui/non): ").strip().lower()
        
        if response not in ['oui', 'o', 'yes', 'y']:
            print("\n❌ Annulé")
            return
        
        # Restaurer
        success = self.manager.restore_version(backup_id)
        
        if success:
            print("\n✅ Version restaurée avec succès !")
            print(f"\n💡 Le prompt actuel a été sauvegardé avant restauration")


def main():
    """Point d'entrée."""
    
    restorer = PromptRestorer()
    
    if len(sys.argv) < 2:
        print("\n❌ Usage: python3 restore_prompt.py [preset_name]")
        print("\nExemple:")
        print("   python3 restore_prompt.py dune_epic")
        return
    
    preset_name = sys.argv[1]
    restorer.restore_interactive(preset_name)


if __name__ == "__main__":
    main()