#!/usr/bin/env python3
"""
Applique les suggestions d'analyse aux prompts avec prévisualisation.
"""

import json
import sys
from pathlib import Path
from prompt_manager import PromptVersionManager

class SuggestionApplicator:
    """Applique les suggestions avec validation utilisateur."""
    
    def __init__(self):
        self.manager = PromptVersionManager()
        self.prompts_dir = Path("prompts")
    
    def load_analysis(self, preset_name: str) -> dict:
        """Charge l'analyse d'un preset."""
        analysis_file = self.prompts_dir / f"{preset_name}_analysis.json"
        
        if not analysis_file.exists():
            print(f"\n❌ Aucune analyse trouvée pour '{preset_name}'")
            print(f"   Lancez d'abord: python3 analyze_inspirations.py {preset_name}")
            return None
        
        with open(analysis_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def preview_changes(self, preset_name: str, analysis: dict):
        """Affiche un aperçu des changements proposés."""
        
        from src.prompt_templates import PRESET_PROMPTS
        
        current = PRESET_PROMPTS.get(preset_name)
        
        if not current:
            print(f"❌ Preset '{preset_name}' introuvable")
            return None
        
        print("\n" + "="*70)
        print(f"📊 PRÉVISUALISATION - {preset_name.upper()}")
        print("="*70)
        
        print(f"\n📷 Basé sur {analysis['image_count']} image(s)")
        
        # Style détecté
        if analysis.get('style_keywords'):
            print("\n🎨 Style détecté:")
            for keyword in analysis['style_keywords']:
                print(f"   • {keyword}")
        
        # Suggestions
        suggestions = analysis.get('suggestions', {})
        
        print("\n💡 Suggestions à ajouter:\n")
        
        enhancements = []
        
        if analysis.get('style_keywords'):
            enhancements.extend(analysis['style_keywords'])
        
        for category, items in suggestions.items():
            if items:
                print(f"   {category.upper()}:")
                for item in items[:2]:  # Top 2
                    print(f"      + {item}")
                    enhancements.append(item)
        
        # Prompt actuel
        print("\n" + "="*70)
        print("📝 PROMPT ACTUEL:")
        print("="*70)
        current_prompt = current["base_prompt"]
        print(f"\n{self._wrap_text(current_prompt)}\n")
        
        # Prompt enrichi
        print("="*70)
        print("✨ PROMPT ENRICHI (PROPOSÉ):")
        print("="*70)
        
        if enhancements:
            enriched_prompt = current_prompt + ", " + ", ".join(enhancements)
        else:
            enriched_prompt = current_prompt
        
        print(f"\n{self._wrap_text(enriched_prompt)}\n")
        
        print("="*70)
        
        return enriched_prompt
    
    def _wrap_text(self, text: str, width: int = 68) -> str:
        """Enveloppe le texte pour meilleure lisibilité."""
        words = text.split()
        lines = []
        current_line = []
        current_length = 0
        
        for word in words:
            if current_length + len(word) + 1 > width:
                lines.append(' '.join(current_line))
                current_line = [word]
                current_length = len(word)
            else:
                current_line.append(word)
                current_length += len(word) + 1
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return '\n'.join(lines)
    
    def apply_with_confirmation(self, preset_name: str):
        """Applique les suggestions après confirmation."""
        
        # Charger l'analyse
        analysis = self.load_analysis(preset_name)
        
        if not analysis:
            return False
        
        # Afficher prévisualisation
        enriched_prompt = self.preview_changes(preset_name, analysis)
        
        if not enriched_prompt:
            return False
        
        # Demander confirmation
        print("\n⚠️  Cette action va:")
        print("   1. Créer un backup du prompt actuel")
        print("   2. Modifier src/prompt_templates.py")
        print("   3. Appliquer le prompt enrichi")
        print("\n   Vous pourrez revenir en arrière avec: python3 restore_prompt.py")
        
        response = input("\n❓ Appliquer ces changements ? (oui/non): ").strip().lower()
        
        if response not in ['oui', 'o', 'yes', 'y']:
            print("\n❌ Annulé - Aucune modification effectuée")
            return False
        
        # Appliquer
        success = self.manager.apply_suggestions(preset_name, analysis)
        
        if success:
            print("\n✅ SUCCÈS - Prompt enrichi appliqué !")
            print(f"\n💡 Prochaines étapes:")
            print(f"   1. Testez: python3 main.py → Preset {preset_name}")
            print(f"   2. Si insatisfait: python3 restore_prompt.py {preset_name}")
        
        return success
    
    def interactive_mode(self):
        """Mode interactif pour choisir le preset."""
        
        from src.prompt_templates import list_presets
        
        print("\n🎨 ENRICHISSEMENT DES PRESETS")
        print("="*70)
        
        # Lister les presets avec analyses disponibles
        presets = list_presets()
        available_analyses = []
        
        print("\n📋 Presets avec analyses disponibles:\n")
        
        for i, preset in enumerate(presets, 1):
            analysis_file = self.prompts_dir / f"{preset}_analysis.json"
            if analysis_file.exists():
                available_analyses.append(preset)
                print(f"   {i}. {preset}")
        
        if not available_analyses:
            print("   ⚠️  Aucune analyse disponible")
            print("\n💡 Lancez d'abord:")
            print("   python3 analyze_inspirations.py [preset_name]")
            return
        
        print("\n" + "="*70)
        
        # Demander choix
        choice = input("\n❓ Choisir un preset (numéro ou nom): ").strip()
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(available_analyses):
                preset_name = available_analyses[idx]
            else:
                print("❌ Numéro invalide")
                return
        elif choice in available_analyses:
            preset_name = choice
        else:
            print("❌ Preset non reconnu ou sans analyse")
            return
        
        # Appliquer
        self.apply_with_confirmation(preset_name)


def main():
    """Point d'entrée principal."""
    
    applicator = SuggestionApplicator()
    
    if len(sys.argv) > 1:
        # Mode ligne de commande
        preset_name = sys.argv[1]
        applicator.apply_with_confirmation(preset_name)
    else:
        # Mode interactif
        applicator.interactive_mode()


if __name__ == "__main__":
    main()