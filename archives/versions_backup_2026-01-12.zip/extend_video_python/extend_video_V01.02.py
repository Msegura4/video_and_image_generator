#!/usr/bin/env python3
"""
Extension de vidéos avec Kling AI.
Permet de prolonger une vidéo existante (5s → 10s).
"""

import os
import sys
import requests
from pathlib import Path
from typing import Optional

# Importer l'API Kling
sys.path.insert(0, str(Path(__file__).parent))
from src.kling_api import KlingAPI


class VideoExtender:
    """Gère l'extension de vidéos avec Kling AI."""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialise l'extendeur de vidéos.
        
        Args:
            api_key: Clé API PiAPI (optionnel si dans .env)
        """
        self.api = KlingAPI(api_key)
        self.outputs_dir = Path("outputs")
    
    def get_video_id_from_file(self, video_path: str) -> Optional[str]:
        """
        Extrait le video_id depuis le fichier metadata ou demande à l'utilisateur.
        
        Args:
            video_path: Chemin de la vidéo
            
        Returns:
            video_id si trouvé
        """
        import json
        
        # Chercher le fichier metadata
        metadata_file = str(video_path).replace('.mp4', '_metadata.json')
        
        if Path(metadata_file).exists():
            print(f"\n✅ Metadata trouvé : {Path(metadata_file).name}")
            
            try:
                with open(metadata_file, 'r') as f:
                    metadata = json.load(f)
                
                video_id = metadata.get('video_id')
                
                if video_id:
                    print(f"🆔 Video ID : {video_id}")
                    if metadata.get('prompt'):
                        print(f"📝 Prompt : {metadata['prompt'][:60]}...")
                    print(f"⏱️  Durée : {metadata.get('duration', 'N/A')}s")
                    
                    confirm = input("\n❓ Utiliser ce Video ID ? (oui/non) [oui] : ").strip().lower()
                    
                    if confirm in ['', 'oui', 'o', 'yes', 'y']:
                        return video_id
            except Exception as e:
                print(f"⚠️  Erreur lecture metadata : {e}")
        
        # Fallback : demander manuellement
        print(f"\n⚠️  Pas de metadata automatique trouvé")
        print(f"📂 Vidéo : {Path(video_path).name}")
        print()
        print("💡 Le Video ID est retourné lors de la génération Kling")
        print("   Format : xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")
        print()
        print("🔍 Comment le trouver :")
        print("   • Vérifiez les logs de génération")
        print("   • Ou laissez vide pour annuler")
        print()
        
        video_id = input("Video ID Kling : ").strip()
        
        if not video_id:
            return None
        
        return video_id
    
    def extend_video(
        self,
        video_id: str,
        prompt: Optional[str] = None,
        mode: str = "professional",
        model_version: str = "2.5"
    ) -> str:
        """
        Prolonge une vidéo de 5s à 10s en utilisant son video_id.
        
        Args:
            video_id: ID de la vidéo Kling à prolonger
            prompt: Prompt optionnel pour guider l'extension
            mode: Mode de génération ("professional" ou "standard")
            model_version: Version du modèle Kling
            
        Returns:
            Chemin de la vidéo étendue
        """
        print("\n" + "="*70)
        print("🎬 EXTENSION DE VIDÉO")
        print("="*70)
        print(f"\n📹 Video ID : {video_id}")
        if prompt:
            print(f"📝 Prompt : {prompt}")
        print(f"⚙️  Mode : {mode}")
        print(f"🎥 Modèle : Kling {model_version}")
        
        # Construire la requête
        endpoint = f"{self.api.base_url}/task"
        
        payload = {
            "model": "kling",
            "task_type": "video_extend",
            "input": {
                "video_id": video_id,
                "mode": "pro" if mode == "professional" else "std",
                "version": model_version
            }
        }
        
        # Ajouter le prompt si fourni
        if prompt:
            payload["input"]["prompt"] = prompt
        
        # Coût estimé (ajoute 4-5s)
        cost = 0.33 if mode == "professional" else 0.26  # Prix pour ~5s supplémentaires
        print(f"\n💰 Coût estimé : ${cost:.2f}")
        print(f"⏱️  Ajoutera ~4-5 secondes à la vidéo")
        
        try:
            print("\n🚀 Lancement de l'extension...")
            response = requests.post(
                endpoint,
                headers=self.api.headers,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            
            result = response.json()
            
            if result.get("code") != 200:
                raise Exception(f"Erreur API : {result.get('message', 'Unknown error')}")
            
            data = result.get("data", {})
            task_id = data.get("task_id")
            
            print(f"✅ Tâche créée : {task_id}")
            
            # Attendre la fin
            print("\n⏳ Génération en cours...")
            completed = self.api.wait_for_completion(task_id)
            
            # Télécharger
            import time
            timestamp = int(time.time())
            output_path = self.outputs_dir / f"extended_{timestamp}.mp4"
            
            final_path = self.api.download_video(completed, str(output_path))
            
            print("\n" + "="*70)
            print("✅ VIDÉO ÉTENDUE AVEC SUCCÈS !")
            print(f"📁 Fichier : {final_path}")
            print("="*70 + "\n")
            
            return final_path
        
        except requests.exceptions.RequestException as e:
            print(f"\n❌ Erreur API : {e}")
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_detail = e.response.json()
                    print(f"Détails : {error_detail}")
                except:
                    print(f"Détails : {e.response.text}")
            raise
    
    def list_generated_videos(self):
        """Liste les vidéos générées dans outputs/."""
        
        if not self.outputs_dir.exists():
            print("❌ Dossier outputs/ introuvable")
            return []
        
        videos = list(self.outputs_dir.glob("*.mp4"))
        
        if not videos:
            print("⚠️  Aucune vidéo trouvée dans outputs/")
            return []
        
        print("\n" + "="*70)
        print("📹 VIDÉOS DISPONIBLES")
        print("="*70 + "\n")
        
        for i, video in enumerate(sorted(videos), 1):
            size_mb = video.stat().st_size / (1024 * 1024)
            print(f"   {i}. {video.name}")
            print(f"      Taille : {size_mb:.2f} MB")
            print()
        
        print("="*70)
        
        return videos
    
    def interactive_extend_generated(self):
        """Mode interactif : prolonger une vidéo du dossier outputs/."""
        
        videos = self.list_generated_videos()
        
        if not videos:
            return
        
        # Choisir une vidéo
        choice = input("\n❓ Choisir une vidéo (numéro) : ").strip()
        
        if not choice.isdigit():
            print("❌ Choix invalide")
            return
        
        idx = int(choice) - 1
        
        if idx < 0 or idx >= len(videos):
            print("❌ Numéro invalide")
            return
        
        video_path = videos[idx]
        
        print(f"\n✅ Vidéo sélectionnée : {video_path.name}")
        
        # Obtenir le video_id
        try:
            video_id = self.get_video_id_from_file(str(video_path))
            
            if not video_id:
                print("\n❌ Video ID requis pour l'extension")
                return
        except Exception as e:
            print(f"❌ Erreur : {e}")
            return
        
        # Prompt optionnel
        print("\n💡 Prompt optionnel pour guider l'extension")
        print("   (Laissez vide pour extension automatique)")
        prompt = input("\nPrompt : ").strip() or None
        
        # Mode
        print("\nMode :")
        print("  1. Professional ($0.33 pour ~5s)")
        print("  2. Standard ($0.26 pour ~5s)")
        mode_choice = input("Choix [1] : ").strip()
        mode = "standard" if mode_choice == "2" else "professional"
        
        # Confirmer
        print("\n" + "="*70)
        print("⚠️  CONFIRMATION")
        print("="*70)
        print(f"\nVidéo    : {video_path.name}")
        print(f"Video ID : {video_id}")
        print(f"Mode     : {mode}")
        if prompt:
            print(f"Prompt   : {prompt}")
        print(f"\nCoût : ${0.33 if mode == 'professional' else 0.26:.2f}")
        print(f"Ajoutera ~4-5 secondes à la vidéo")
        
        confirm = input("\n❓ Lancer l'extension ? (oui/non) : ").strip().lower()
        
        if confirm not in ['oui', 'o', 'yes', 'y']:
            print("\n❌ Annulé")
            return
        
        # Extend
        try:
            extended_path = self.extend_video(video_id, prompt, mode)
            print(f"\n✅ Vidéo étendue : {extended_path}")
        except Exception as e:
            print(f"\n❌ Erreur : {e}")
    
    def interactive_extend_custom(self):
        """Mode interactif : prolonger une vidéo avec video_id."""
        
        print("\n" + "="*70)
        print("🎬 EXTENSION AVEC VIDEO ID KLING")
        print("="*70)
        print("\n💡 Entrez le Video ID d'une vidéo générée avec Kling")
        print("   (Format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)")
        print()
        
        video_id = input("Video ID Kling : ").strip()
        
        if not video_id:
            print("❌ Video ID requis")
            return
        
        # Prompt optionnel
        print("\n💡 Prompt optionnel pour guider l'extension")
        prompt = input("Prompt : ").strip() or None
        
        # Mode
        print("\nMode :")
        print("  1. Professional ($0.33 pour ~5s)")
        print("  2. Standard ($0.26 pour ~5s)")
        mode_choice = input("Choix [1] : ").strip()
        mode = "standard" if mode_choice == "2" else "professional"
        
        # Confirmer
        print("\n" + "="*70)
        print("⚠️  CONFIRMATION")
        print("="*70)
        print(f"\nVideo ID : {video_id}")
        print(f"Mode     : {mode}")
        if prompt:
            print(f"Prompt   : {prompt}")
        
        confirm = input("\n❓ Lancer l'extension ? (oui/non) : ").strip().lower()
        
        if confirm not in ['oui', 'o', 'yes', 'y']:
            print("\n❌ Annulé")
            return
        
        # Extend
        try:
            extended_path = self.extend_video(video_id, prompt, mode)
            print(f"\n✅ Vidéo étendue : {extended_path}")
        except Exception as e:
            print(f"\n❌ Erreur : {e}")


def main():
    """Point d'entrée."""
    
    print("\n🎬 EXTENSION DE VIDÉOS KLING AI")
    print("="*70)
    print("\n1. Prolonger une vidéo générée (outputs/)")
    print("2. Prolonger une vidéo externe (URL)")
    print("0. Annuler")
    
    choice = input("\nChoix : ").strip()
    
    try:
        extender = VideoExtender()
        
        if choice == "1":
            extender.interactive_extend_generated()
        elif choice == "2":
            extender.interactive_extend_custom()
        elif choice == "0":
            print("\n❌ Annulé")
        else:
            print("\n❌ Choix invalide")
    
    except Exception as e:
        print(f"\n❌ Erreur : {e}")


if __name__ == "__main__":
    main()
