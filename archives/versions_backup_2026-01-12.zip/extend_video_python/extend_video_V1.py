#!/usr/bin/env python3
"""
Extension de vidéos avec Kling AI.
Permet de prolonger une vidéo existante (5s → 10s).
"""

import os
import sys
import requests
from pathlib import Path
from typing import Optional

# Importer l'API Kling
sys.path.insert(0, str(Path(__file__).parent))
from src.kling_api import KlingAPI


class VideoExtender:
    """Gère l'extension de vidéos avec Kling AI."""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialise l'extendeur de vidéos.
        
        Args:
            api_key: Clé API PiAPI (optionnel si dans .env)
        """
        self.api = KlingAPI(api_key)
        self.outputs_dir = Path("outputs")
    
    def upload_video_to_hosting(self, video_path: str) -> str:
        """
        Upload une vidéo vers un service d'hébergement temporaire.
        
        Args:
            video_path: Chemin local de la vidéo
            
        Returns:
            URL publique de la vidéo
        """
        # Importer l'uploader
        try:
            from video_uploader import VideoUploader
            return VideoUploader.interactive_upload(video_path)
        except ImportError:
            # Fallback : demander URL manuellement
            print(f"\n⚠️  IMPORTANT : Kling AI nécessite une URL publique de la vidéo")
            print(f"📂 Vidéo locale : {video_path}")
            print()
            print("💡 Options pour héberger votre vidéo :")
            print("   1. Uploadez sur https://0x0.st (temporaire, 30 jours)")
            print("   2. Uploadez sur https://tmpfiles.org (temporaire, 7 jours)")
            print("   3. Utilisez votre propre hébergement (S3, Cloudflare R2, etc.)")
            print()
            
            video_url = input("Entrez l'URL publique de votre vidéo : ").strip()
            
            if not video_url:
                raise ValueError("❌ URL vidéo requise")
            
            return video_url
    
    def extend_video(
        self,
        video_url: str,
        prompt: Optional[str] = None,
        mode: str = "professional",
        model_version: str = "2.5"
    ) -> str:
        """
        Prolonge une vidéo de 5s à 10s.
        
        Args:
            video_url: URL publique de la vidéo source
            prompt: Prompt optionnel pour guider l'extension
            mode: Mode de génération ("professional" ou "standard")
            model_version: Version du modèle Kling
            
        Returns:
            Chemin de la vidéo étendue
        """
        print("\n" + "="*70)
        print("🎬 EXTENSION DE VIDÉO")
        print("="*70)
        print(f"\n📹 Vidéo source : {video_url}")
        if prompt:
            print(f"📝 Prompt : {prompt}")
        print(f"⚙️  Mode : {mode}")
        print(f"🎥 Modèle : Kling {model_version}")
        
        # Construire la requête
        endpoint = f"{self.api.base_url}/task"
        
        payload = {
            "model": "kling",
            "task_type": "video_extension",  # Type spécifique pour extend
            "input": {
                "video_url": video_url,
                "mode": "pro" if mode == "professional" else "std",
                "version": model_version
            }
        }
        
        # Ajouter le prompt si fourni
        if prompt:
            payload["input"]["prompt"] = prompt
        
        # Coût estimé
        cost = 0.66 if mode == "professional" else 0.52  # Prix pour 10s
        print(f"\n💰 Coût estimé : ${cost:.2f}")
        
        try:
            print("\n🚀 Lancement de l'extension...")
            response = requests.post(
                endpoint,
                headers=self.api.headers,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            
            result = response.json()
            
            if result.get("code") != 200:
                raise Exception(f"Erreur API : {result.get('message', 'Unknown error')}")
            
            data = result.get("data", {})
            task_id = data.get("task_id")
            
            print(f"✅ Tâche créée : {task_id}")
            
            # Attendre la fin
            print("\n⏳ Génération en cours...")
            completed = self.api.wait_for_completion(task_id)
            
            # Télécharger
            import time
            timestamp = int(time.time())
            output_path = self.outputs_dir / f"extended_{timestamp}.mp4"
            
            final_path = self.api.download_video(completed, str(output_path))
            
            print("\n" + "="*70)
            print("✅ VIDÉO ÉTENDUE AVEC SUCCÈS !")
            print(f"📁 Fichier : {final_path}")
            print("="*70 + "\n")
            
            return final_path
        
        except requests.exceptions.RequestException as e:
            print(f"\n❌ Erreur API : {e}")
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_detail = e.response.json()
                    print(f"Détails : {error_detail}")
                except:
                    print(f"Détails : {e.response.text}")
            raise
    
    def list_generated_videos(self):
        """Liste les vidéos générées dans outputs/."""
        
        if not self.outputs_dir.exists():
            print("❌ Dossier outputs/ introuvable")
            return []
        
        videos = list(self.outputs_dir.glob("*.mp4"))
        
        if not videos:
            print("⚠️  Aucune vidéo trouvée dans outputs/")
            return []
        
        print("\n" + "="*70)
        print("📹 VIDÉOS DISPONIBLES")
        print("="*70 + "\n")
        
        for i, video in enumerate(sorted(videos), 1):
            size_mb = video.stat().st_size / (1024 * 1024)
            print(f"   {i}. {video.name}")
            print(f"      Taille : {size_mb:.2f} MB")
            print()
        
        print("="*70)
        
        return videos
    
    def interactive_extend_generated(self):
        """Mode interactif : prolonger une vidéo du dossier outputs/."""
        
        videos = self.list_generated_videos()
        
        if not videos:
            return
        
        # Choisir une vidéo
        choice = input("\n❓ Choisir une vidéo (numéro) : ").strip()
        
        if not choice.isdigit():
            print("❌ Choix invalide")
            return
        
        idx = int(choice) - 1
        
        if idx < 0 or idx >= len(videos):
            print("❌ Numéro invalide")
            return
        
        video_path = videos[idx]
        
        print(f"\n✅ Vidéo sélectionnée : {video_path.name}")
        
        # Upload vers hébergement
        try:
            video_url = self.upload_video_to_hosting(str(video_path))
        except Exception as e:
            print(f"❌ Erreur : {e}")
            return
        
        # Prompt optionnel
        print("\n💡 Prompt optionnel pour guider l'extension")
        print("   (Laissez vide pour extension automatique)")
        prompt = input("\nPrompt : ").strip() or None
        
        # Mode
        print("\nMode :")
        print("  1. Professional ($0.66)")
        print("  2. Standard ($0.52)")
        mode_choice = input("Choix [1] : ").strip()
        mode = "standard" if mode_choice == "2" else "professional"
        
        # Confirmer
        print("\n" + "="*70)
        print("⚠️  CONFIRMATION")
        print("="*70)
        print(f"\nVidéo : {video_path.name}")
        print(f"Mode  : {mode}")
        if prompt:
            print(f"Prompt : {prompt}")
        print(f"\nCoût : ${0.66 if mode == 'professional' else 0.52:.2f}")
        
        confirm = input("\n❓ Lancer l'extension ? (oui/non) : ").strip().lower()
        
        if confirm not in ['oui', 'o', 'yes', 'y']:
            print("\n❌ Annulé")
            return
        
        # Extend
        try:
            extended_path = self.extend_video(video_url, prompt, mode)
            print(f"\n✅ Vidéo étendue : {extended_path}")
        except Exception as e:
            print(f"\n❌ Erreur : {e}")
    
    def interactive_extend_custom(self):
        """Mode interactif : prolonger une vidéo externe."""
        
        print("\n" + "="*70)
        print("🎬 EXTENSION DE VIDÉO EXTERNE")
        print("="*70)
        print("\n💡 Fournissez l'URL publique d'une vidéo à prolonger")
        print("   (La vidéo doit être accessible publiquement)")
        print()
        
        video_url = input("URL de la vidéo : ").strip()
        
        if not video_url:
            print("❌ URL requise")
            return
        
        # Prompt optionnel
        print("\n💡 Prompt optionnel pour guider l'extension")
        prompt = input("Prompt : ").strip() or None
        
        # Mode
        print("\nMode :")
        print("  1. Professional ($0.66)")
        print("  2. Standard ($0.52)")
        mode_choice = input("Choix [1] : ").strip()
        mode = "standard" if mode_choice == "2" else "professional"
        
        # Confirmer
        print("\n" + "="*70)
        print("⚠️  CONFIRMATION")
        print("="*70)
        print(f"\nURL   : {video_url}")
        print(f"Mode  : {mode}")
        if prompt:
            print(f"Prompt : {prompt}")
        
        confirm = input("\n❓ Lancer l'extension ? (oui/non) : ").strip().lower()
        
        if confirm not in ['oui', 'o', 'yes', 'y']:
            print("\n❌ Annulé")
            return
        
        # Extend
        try:
            extended_path = self.extend_video(video_url, prompt, mode)
            print(f"\n✅ Vidéo étendue : {extended_path}")
        except Exception as e:
            print(f"\n❌ Erreur : {e}")


def main():
    """Point d'entrée."""
    
    print("\n🎬 EXTENSION DE VIDÉOS KLING AI")
    print("="*70)
    print("\n1. Prolonger une vidéo générée (outputs/)")
    print("2. Prolonger une vidéo externe (URL)")
    print("0. Annuler")
    
    choice = input("\nChoix : ").strip()
    
    try:
        extender = VideoExtender()
        
        if choice == "1":
            extender.interactive_extend_generated()
        elif choice == "2":
            extender.interactive_extend_custom()
        elif choice == "0":
            print("\n❌ Annulé")
        else:
            print("\n❌ Choix invalide")
    
    except Exception as e:
        print(f"\n❌ Erreur : {e}")


if __name__ == "__main__":
    main()
