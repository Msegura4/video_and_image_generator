#!/usr/bin/env python3
"""
Gestionnaire de versions pour les prompts.
Permet de sauvegarder, restaurer et comparer les versions.
VERSION CORRIGÉE - Cherche dans prompts/ ET src/
"""

import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

class PromptVersionManager:
    """Gère les versions des prompts avec historique."""
    
    def __init__(self):
        # Chercher le fichier de templates (prompts/ prioritaire, puis src/)
        if Path("prompts/prompt_templates.py").exists():
            self.templates_file = Path("prompts/prompt_templates.py")
            self.dict_name = "STYLE_PRESETS"
            print("📂 Utilisation de: prompts/prompt_templates.py")
        elif Path("src/prompt_templates.py").exists():
            self.templates_file = Path("src/prompt_templates.py")
            self.dict_name = "PRESET_PROMPTS"
            print("📂 Utilisation de: src/prompt_templates.py")
        else:
            raise FileNotFoundError("❌ Aucun fichier prompt_templates.py trouvé dans prompts/ ou src/")
        
        self.backup_dir = Path("prompts/backups")
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.history_file = self.backup_dir / "history.json"
        
        # Charger l'historique
        self.history = self._load_history()
    
    def _load_history(self) -> Dict:
        """Charge l'historique des versions."""
        if self.history_file.exists():
            with open(self.history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_history(self):
        """Sauvegarde l'historique."""
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, indent=2, ensure_ascii=False)
    
    def _load_presets(self):
        """Charge les presets depuis le fichier."""
        # Import dynamique selon le fichier trouvé
        if "prompts" in str(self.templates_file):
            from prompts.prompt_templates import STYLE_PRESETS
            return STYLE_PRESETS
        else:
            from src.prompt_templates import PRESET_PROMPTS
            return PRESET_PROMPTS
    
    def create_backup(self, preset_name: str, reason: str = "manual_backup") -> str:
        """
        Crée un backup du prompt actuel.
        
        Returns:
            backup_id: Identifiant unique du backup
        """
        # Lire le prompt actuel
        PRESETS = self._load_presets()
        current_prompt = PRESETS.get(preset_name)
        
        if not current_prompt:
            raise ValueError(f"Preset '{preset_name}' introuvable")
        
        # Générer ID unique
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_id = f"{preset_name}_{timestamp}"
        
        # Sauvegarder
        backup_file = self.backup_dir / f"{backup_id}.json"
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump({
                "preset_name": preset_name,
                "timestamp": timestamp,
                "reason": reason,
                "prompt": current_prompt
            }, f, indent=2, ensure_ascii=False)
        
        # Ajouter à l'historique
        if preset_name not in self.history:
            self.history[preset_name] = []
        
        self.history[preset_name].append({
            "backup_id": backup_id,
            "timestamp": timestamp,
            "reason": reason,
            "file": str(backup_file)
        })
        
        self._save_history()
        
        print(f"✅ Backup créé: {backup_id}")
        return backup_id
    
    def get_versions(self, preset_name: str) -> List[Dict]:
        """Récupère toutes les versions d'un preset."""
        return self.history.get(preset_name, [])
    
    def get_version(self, backup_id: str) -> Optional[Dict]:
        """Récupère une version spécifique."""
        backup_file = self.backup_dir / f"{backup_id}.json"
        
        if not backup_file.exists():
            return None
        
        with open(backup_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def compare_versions(self, preset_name: str, backup_id: Optional[str] = None) -> Dict:
        """Compare la version actuelle avec une ancienne version."""
        PRESETS = self._load_presets()
        current = PRESETS.get(preset_name)
        
        if backup_id:
            previous = self.get_version(backup_id)
        else:
            # Prendre la dernière version
            versions = self.get_versions(preset_name)
            if not versions:
                return {"current": current, "previous": None}
            
            backup_id = versions[-1]["backup_id"]
            previous = self.get_version(backup_id)
        
        return {
            "current": current,
            "previous": previous["prompt"] if previous else None,
            "backup_id": backup_id
        }
    
    def restore_version(self, backup_id: str) -> bool:
        """Restaure une version précédente."""
        backup = self.get_version(backup_id)
        
        if not backup:
            print(f"❌ Version {backup_id} introuvable")
            return False
        
        preset_name = backup["preset_name"]
        
        # Créer un backup de la version actuelle avant de restaurer
        self.create_backup(preset_name, reason="before_restore")
        
        # Modifier prompt_templates.py
        self._update_prompt_in_file(preset_name, backup["prompt"])
        
        print(f"✅ Version restaurée: {backup_id}")
        return True
    
    def _update_prompt_in_file(self, preset_name: str, new_prompt_data: Dict):
        """Met à jour le prompt dans prompt_templates.py."""
        
        # Lire le fichier actuel
        with open(self.templates_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Import pour obtenir la structure
        PRESETS = self._load_presets()
        
        # Mettre à jour en mémoire
        PRESETS[preset_name] = new_prompt_data
        
        # Reconstruire le fichier
        new_content = self._rebuild_file_content(PRESETS)
        
        # Écrire
        with open(self.templates_file, 'w', encoding='utf-8') as f:
            f.write(new_content)
    
    def _rebuild_file_content(self, presets: Dict) -> str:
        """Reconstruit le contenu du fichier prompt_templates.py."""
        
        lines = [
            '"""',
            'Templates de prompts pour chaque preset.',
            'Organisés par style visuel.',
            '"""',
            '',
            f'{self.dict_name} = {{'
        ]
        
        for i, (preset_name, preset_data) in enumerate(presets.items()):
            lines.append(f'    "{preset_name}": {{')
            
            # Gérer les deux formats (base/color/camera OU base_prompt/negative_prompt)
            if "base" in preset_data:
                # Ancien format (prompts/prompt_templates.py)
                lines.append(f'        "base": "{preset_data["base"]}",')
                lines.append(f'        "color": "{preset_data.get("color", "")}",')
                lines.append(f'        "camera": "{preset_data.get("camera", "")}",')
                lines.append(f'        "quality": "{preset_data.get("quality", "")}"')
            else:
                # Nouveau format (src/prompt_templates.py)
                lines.append(f'        "name": "{preset_data.get("name", preset_name)}",')
                lines.append(f'        "description": "{preset_data.get("description", "")}",')
                lines.append(f'        "base_prompt": "{preset_data.get("base_prompt", "")}",')
                lines.append(f'        "negative_prompt": "{preset_data.get("negative_prompt", "")}",')
                
                # Style keywords
                keywords = preset_data.get("style_keywords", [])
                lines.append(f'        "style_keywords": [')
                for keyword in keywords:
                    lines.append(f'            "{keyword}",')
                lines.append(f'        ],')
                
                # Recommended settings
                settings = preset_data.get("recommended_settings", {})
                lines.append(f'        "recommended_settings": {{')
                lines.append(f'            "aspect_ratio": "{settings.get("aspect_ratio", "16:9")}",')
                lines.append(f'            "duration": {settings.get("duration", 5)},')
                lines.append(f'            "mode": "{settings.get("mode", "standard")}"')
                lines.append(f'        }}')
            
            if i < len(presets) - 1:
                lines.append('    },')
            else:
                lines.append('    }')
        
        lines.append('}')
        lines.append('')
        
        return '\n'.join(lines)
    
    def apply_suggestions(self, preset_name: str, analysis_data: Dict) -> bool:
        """Applique les suggestions d'analyse à un preset."""
        
        PRESETS = self._load_presets()
        
        if preset_name not in PRESETS:
            print(f"❌ Preset '{preset_name}' introuvable")
            return False
        
        # Créer backup avant modification
        self.create_backup(preset_name, reason="before_enrichment")
        
        # Construire le nouveau prompt
        current_prompt = PRESETS[preset_name]
        
        # Déterminer le format
        if "base" in current_prompt:
            base_prompt = current_prompt["base"]
        else:
            base_prompt = current_prompt.get("base_prompt", "")
        
        # Ajouter les suggestions
        enhancements = []
        
        if analysis_data.get('style_keywords'):
            enhancements.extend(analysis_data['style_keywords'])
        
        suggestions = analysis_data.get('suggestions', {})
        for category, items in suggestions.items():
            enhancements.extend(items[:2])  # Top 2 de chaque catégorie
        
        if enhancements:
            new_base_prompt = base_prompt + ", " + ", ".join(enhancements)
        else:
            new_base_prompt = base_prompt
        
        # Mettre à jour
        new_prompt_data = current_prompt.copy()
        if "base" in new_prompt_data:
            new_prompt_data["base"] = new_base_prompt
        else:
            new_prompt_data["base_prompt"] = new_base_prompt
        
        self._update_prompt_in_file(preset_name, new_prompt_data)
        
        print(f"✅ Prompt enrichi pour '{preset_name}'")
        return True


def main():
    """Test du gestionnaire."""
    manager = PromptVersionManager()
    
    print("🔧 GESTIONNAIRE DE VERSIONS DE PROMPTS")
    print("="*70)
    
    # Lister les presets avec historique
    PRESETS = manager._load_presets()
    
    for preset in PRESETS.keys():
        versions = manager.get_versions(preset)
        print(f"\n📦 {preset}: {len(versions)} version(s)")


if __name__ == "__main__":
    main()
