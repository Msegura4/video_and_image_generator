"""
Templates de prompts pour chaque preset.
Organisés par style visuel.
"""

PRESET_PROMPTS = {
    "dune_epic": {
        "name": "Dune Epic",
        "description": "Paysages désertiques épiques, monumentaux et contemplatifs",
        "base_prompt": "Vast desert landscape under a massive sun, towering sand dunes stretching to infinity, monumental scale, golden sand, deep blue sky, dramatic shadows, epic composition, sense of scale and majesty, cinematic wide shot, cinematic wide composition, heat haze, dust particles in air, ultra-wide angle, panoramic vista, cinematic wide composition, heat haze, dust particles in air, ultra-wide angle, panoramic vista, cinematic wide composition, moody lighting, soft shadows, heat haze, dust particles in air, ultra-wide angle, panoramic vista, cinematic wide composition, moody lighting, soft shadows, heat haze, dust particles in air, ultra-wide angle, panoramic vista",
        "negative_prompt": "people, characters, vehicles, buildings, green vegetation, water, clouds, motion blur, lens flare",
        "style_keywords": [
            "epic scale",
            "golden hour",
            "desert vastness",
            "monumental",
            "contemplative mood",
        ],
        "recommended_settings": {
            "aspect_ratio": "16:9",
            "duration": 10,
            "mode": "professional"
        }
    },
    "arrival_minimal": {
        "name": "Arrival Minimal",
        "description": "Minimalisme contemplatif, architecture alien mystérieuse",
        "base_prompt": "Minimalist alien architecture, vast empty space, mysterious geometric structure, contemplative atmosphere, fog and mist, sense of wonder and otherworldliness, serene and enigmatic mood, cinematic composition, muted colors",
        "negative_prompt": "people, crowds, action, bright colors, busy composition, clutter, detailed textures",
        "style_keywords": [
            "minimalist",
            "contemplative",
            "alien architecture",
            "mysterious",
            "muted palette",
        ],
        "recommended_settings": {
            "aspect_ratio": "21:9",
            "duration": 10,
            "mode": "professional"
        }
    },
"dune_brutalist_ship": {
    "name": "Dune Brutalist Spaceship - Moving",
    "description": "Vaisseau brutaliste en mouvement dans le désert, planète rose en fond, palette golden hour",
    "base_prompt": (
        "First-person POV steadily moving forward through vast desert landscape, "
        "smooth forward dolly tracking shot, "
        "massive cylindrical brutalist spaceship slowly drifting across the sky, "
        "enormous stone concrete spacecraft in motion, "
        "brutalist architecture vessel moving gracefully, "
        "monumental geometric structure hovering and advancing, "
        "towering alien ship stretching to infinity, "
        "massive pink planet rising on the horizon in background, "
        "monumental scale, golden sand, deep blue sky with rose pink hues, "
        "golden hour warm lighting with pink sunset tones, "
        "dramatic shadows, epic composition, "
        "sense of scale and majesty, "
        "cinematic wide shot, cinematic wide composition, "
        "heat haze, dust particles in air, "
        "ultra-wide angle, panoramic vista, "
        "cinematic wide composition, "
        "heat haze, dust particles in air, "
        "ultra-wide angle, panoramic vista, "
        "cinematic wide composition, "
        "moody lighting, soft shadows, "
        "golden hour atmosphere with pink atmospheric glow, "
        "heat haze, dust particles in air, "
        "ultra-wide angle, panoramic vista, "
        "cinematic wide composition, "
        "moody lighting, soft shadows, "
        "heat haze, dust particles in air, "
        "ultra-wide angle, panoramic vista"
    ),
    "negative_prompt": "people, characters, vehicles, buildings, green vegetation, water, clouds, motion blur, lens flare, metallic shiny surface, chrome, reflective metal, static stationary spaceship",
    "style_keywords": [
        "epic scale",
        "golden hour",
        "desert vastness",
        "brutalist spacecraft in motion",
        "pink planet",
        "monumental",
        "contemplative mood",
    ],
    "recommended_settings": {
        "aspect_ratio": "16:9",
        "duration": 10,
        "mode": "professional"
    }
}
    },
    "human_contemplative": {
        "name": "Human Contemplative",
        "description": "Portraits humains méditatifs et émotionnels",
        "base_prompt": "Human figure in deep contemplation, intimate portrait moment, emotional depth and vulnerability, cinematic lighting, shallow depth of field, thoughtful expression, quiet introspection, dramatic shadows, rich skin tones",
        "negative_prompt": "multiple people, action, movement, bright colors, busy background, smile, looking at camera",
        "style_keywords": [
            "intimate portrait",
            "emotional depth",
            "contemplative mood",
            "cinematic lighting",
            "introspective",
        ],
        "recommended_settings": {
            "aspect_ratio": "9:16",
            "duration": 5,
            "mode": "professional"
        }
    },
    "brutalist_architecture": {
        "name": "Brutalist Architecture",
        "description": "Architecture brutaliste massive et imposante",
        "base_prompt": "Massive concrete brutalist structure, geometric architectural forms, imposing monumental scale, dramatic angles and perspectives, raw concrete textures, sense of weight and permanence, stark modernist composition, dramatic lighting and shadows",
        "negative_prompt": "people, vegetation, decorations, warm colors, soft lighting, organic shapes",
        "style_keywords": [
            "brutalist architecture",
            "geometric forms",
            "concrete textures",
            "monumental scale",
            "stark composition",
        ],
        "recommended_settings": {
            "aspect_ratio": "16:9",
            "duration": 10,
            "mode": "professional"
        }
    },
    "portal_tunnel": {
        "name": "Portal Tunnel",
        "description": "Tunnels et passages mystérieux vers l'inconnu",
        "base_prompt": "Mysterious tunnel passage leading into unknown, otherworldly corridor with strange geometry, journey through dimensional portal, sense of depth and perspective, surreal atmosphere, enigmatic lighting effects, cinematic tunnel shot, transformative passage",
        "negative_prompt": "people, vehicles, everyday objects, realistic textures, bright daylight, cluttered details",
        "style_keywords": [
            "mysterious passage",
            "otherworldly corridor",
            "dimensional portal",
            "surreal atmosphere",
            "depth perspective",
        ],
        "recommended_settings": {
            "aspect_ratio": "21:9",
            "duration": 10,
            "mode": "professional"
        }
    },
    "underwater_alien": {
        "name": "Underwater Alien",
        "description": "Profondeurs extraterrestres et bioluminescentes",
        "base_prompt": "Deep underwater alien environment, bioluminescent creatures and flora, mysterious ocean depths, surreal aquatic atmosphere, ethereal lighting from unknown sources, sense of wonder and otherworldliness, fluid movements, dreamlike underwater scene",
        "negative_prompt": "humans, boats, fish, realistic ocean, surface visible, bright sunlight, shallow water",
        "style_keywords": [
            "alien ocean",
            "bioluminescence",
            "mysterious depths",
            "surreal aquatic",
            "ethereal atmosphere",
        ],
        "recommended_settings": {
            "aspect_ratio": "16:9",
            "duration": 10,
            "mode": "professional"
        }
    },
    "custom": {
        "name": "Custom",
        "description": "Votre style personnalisé",
        "base_prompt": "Cinematic scene with dramatic composition and atmospheric lighting, professional cinematography, carefully crafted visual storytelling",
        "negative_prompt": "amateur, low quality, blurry, distorted",
        "style_keywords": [
            "cinematic",
            "professional",
            "atmospheric",
            "carefully composed",
        ],
        "recommended_settings": {
            "aspect_ratio": "16:9",
            "duration": 5,
            "mode": "standard"
        }
    }
}


def get_preset_prompt(preset_name: str) -> dict:
    """Récupère le prompt template d'un preset."""
    return PRESET_PROMPTS.get(preset_name, PRESET_PROMPTS["custom"])


def list_presets() -> list:
    """Liste tous les presets disponibles."""
    return list(PRESET_PROMPTS.keys())
