"""
Templates de prompts pour chaque preset.
Organisés par style visuel.
"""

STYLE_PRESETS = {
    "dune_epic": {
        "base": "Vast desert landscape under a massive sun, towering sand dunes stretching to infinity, monumental scale, golden sand, deep blue sky, dramatic shadows, epic composition, sense of scale and majesty, cinematic wide shot, cinematic wide composition, heat haze, dust particles in air, ultra-wide angle, panoramic vista, cinematic wide composition, heat haze, dust particles in air, ultra-wide angle, panoramic vista, cinematic wide composition, moody lighting, soft shadows, heat haze, dust particles in air, ultra-wide angle, panoramic vista, cinematic wide composition, moody lighting, soft shadows, heat haze, dust particles in air, ultra-wide angle, panoramic vista",
        "color": "desaturated earth tones with rose and burgundy hues, warm golden hour lighting",
        "camera": "static camera, slight drift forward, 35mm anamorphic lens",
        "quality": "8K, film grain, Denis Villeneuve cinematography"
    },
    "arrival_minimal": {
        "base": "Minimalist composition, massive geometric structure hovering in misty atmosphere",
        "color": "muted gray-blue palette, diffused natural light, atmospheric haze",
        "camera": "slow upward tilt, static frame, wide angle lens",
        "quality": "photorealistic, cinematic, high detail"
    },
    "spaceship_arrival": {
        "base": "Colossal alien spacecraft descending over landscape",
        "color": "desaturated palette, dramatic sky, volumetric lighting",
        "camera": "slow camera rise, tracking shot, epic reveal",
        "quality": "8K, VFX quality, realistic physics"
    },
    "human_contemplative": {
        "base": "Lone figure standing before massive architectural structure",
        "color": "rose and burgundy tones, theatrical lighting, soft shadows",
        "camera": "static frame, centered composition, human at lower third",
        "quality": "cinematic, photorealistic, 35mm film aesthetic"
    },
    "brutalist_architecture": {
        "base": "Brutalist megastructure with geometric patterns and symmetry",
        "color": "concrete grays, muted tones, subtle color grading",
        "camera": "slow dolly forward, centered framing, architectural photography",
        "quality": "hyperrealistic, architectural visualization, sharp detail"
    },
    "underwater_alien": {
        "base": "Submerged monolithic structures in murky depths",
        "color": "deep blue-green tones, volumetric god rays, bioluminescence",
        "camera": "floating drift, slow rotation, underwater cinematography",
        "quality": "photorealistic water physics, cinematic lighting"
    },
    "portal_tunnel": {
        "base": "Spiraling tunnel of clouds and light, cosmic wormhole, moody lighting, soft shadows",
        "color": "dramatic contrast, bright core, swirling textures",
        "camera": "forward movement through tunnel, accelerating pace",
        "quality": "VFX quality, physically accurate, 8K detail"
    }
}
